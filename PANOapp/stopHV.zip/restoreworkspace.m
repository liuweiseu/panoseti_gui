desktop = com.mathworks.mde.desk.MLDesktop.getInstance;
desktop.restoreLayout('Default')