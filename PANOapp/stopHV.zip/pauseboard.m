[ig,indexacqmode]=ismember(['ACQMODE '] ,quaboconfig);
    quaboconfig(indexacqmode,2)={"0x01"};
    
   quaboconfig=changepe(30.,gain,quaboconfig); 
    sentacqparams2board(quaboconfig)